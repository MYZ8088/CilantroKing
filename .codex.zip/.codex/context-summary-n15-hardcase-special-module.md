﻿## 项目上下文摘要（n15-hardcase-special-module）

生成时间：2026-04-25 20:08:12

### 1. 相似实现分析
- **实现1**: solver.py:4008
  - 模式：按簇分流（j==k / containment / general）进入专用 refine 模块
  - 可复用：_phase_i_nlt16_cluster_specialized_refine、_phase_i_jk_cycle_module
  - 需注意：依赖 _deadline_at 和 _time_remaining_sec，避免抢占主流程预算
- **实现2**: solver.py:4393
  - 模式：结构化 refine（orbit + iterative SAT）
  - 可复用：_phase_k_cluster_structural_refine、_phase_k_containment_iterative_sat_refine、_phase_k_general_iterative_sat_refine
  - 需注意：仅在 cp-sat 可用且规模门槛满足时触发
- **实现3**: solver.py:3541
  - 模式：固定目标长度打靶（drop/repair + tabu + 动态权重）
  - 可复用：_phase_g_try_target_len
  - 需注意：调用前必须保证 _cov_table/_inv_table 已构建，且每轮预算受限

### 2. 项目约定
- **命名约定**: 私有阶段函数以 _phase_* 命名，布尔开关使用 _xxx_enabled
- **文件组织**: 核心求解在 solver.py，可复用模块独立成单文件并由 solver 调度
- **导入顺序**: 标准库 -> 第三方 -> 本地模块
- **代码风格**: 4空格缩进，类型标注，短早返回，预算驱动的阶段式流程

### 3. 可复用组件清单
- solver.py:_phase_g_try_target_len：定长压缩核心
- solver.py:_phase_i_full_cp_sat_module：全局 cp-sat 精修
- solver.py:_phase_k_*_refine：按簇结构化 refinement
- solver.py:_time_remaining_sec：统一预算入口

### 4. 测试策略
- **测试框架**: 现有 pytest + 评测脚本 evaluate_n_lt_18_compliance.py
- **测试模式**: 本次采用功能回归（仅15个不合规 case）
- **参考文件**: esults/n_lt_16_remaining20_after_opt_v19_recover.json
- **覆盖要求**: 只验证质量门槛（<=10%）和 verified，不跑全量

### 5. 依赖和集成点
- **外部依赖**: OR-Tools CP-SAT（可选）
- **内部依赖**: solver 内部阶段方法复用
- **集成方式**: 在 solver.solve() 尾部阶段插入可开关 dispatch
- **配置来源**: 环境变量 CK_N15_HARDCASE_MODULE

### 6. 技术选型理由
- **为什么用独立模块**: 满足“不动主逻辑”要求，风险可控
- **优势**: 仅命中15个指定case，最小化回归影响
- **劣势和风险**: 预算分配不当可能压缩不足；需用15-case回归迭代

### 7. 关键风险点
- **并发问题**: 子进程并发评测下需保证模块无全局可变状态
- **边界条件**: cp-sat不可用、预算不足、候选映射缺失
- **性能瓶颈**: _phase_g_try_target_len 在大候选空间下耗时
- **安全考虑**: 无新增安全逻辑
