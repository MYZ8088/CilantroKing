﻿## 项目上下文摘要（n16-owned-routing）

生成时间：2026-04-25 20:32:18

### 1. 相似实现分析
- **实现1**: evaluate_n_lt_18_compliance.py:117
  - 模式：子进程运行单 case，环境变量注入求解参数
  - 可复用：`_run_one_case_subprocess` 的命令组装与 JSON 回传
  - 需注意：当前是全局 `CK_SOLVER_MODULE`，会导致 n=16 受整体参数联动
- **实现2**: evaluate_n_lt_18_compliance.py:646
  - 模式：主流程 `_main_eval` 对 case 批量并发调度
  - 可复用：串行/并行统一评测与 checkpoint 落盘
  - 需注意：需要在这里插入按 n 分流，否则只是并列脚本
- **实现3**: run_n16_isolated_pipeline.py:45
  - 模式：外层包装脚本把参数转发到主评测脚本
  - 可复用：n=16 专用参数集合（solver module / cpsat / anchor）
  - 需注意：当前是“并列入口”，未成为主流程的“所属分支”
- **实现4**: solver.py:1382
  - 模式：求解器内部已有 `n==16` 的 anchor 分派
  - 可复用：n=16 作为独立策略簇的思路
  - 需注意：上层入口若不隔离参数，仍会影响该策略执行效果

### 2. 项目约定
- **命名约定**: 私有函数前缀 `_`，参数名使用 `ck_*` 保持环境变量一致
- **文件组织**: 评测入口在 `evaluate_n_lt_18_compliance.py`，特化脚本在 `run_n16_isolated_pipeline.py`
- **导入顺序**: 标准库 -> 第三方库 -> 本地常量/函数
- **代码风格**: 类型标注 + 小函数 + 串并行双路径一致行为

### 3. 可复用组件清单
- `evaluate_n_lt_18_compliance.py:_run_one_case_subprocess`：子进程执行与超时保护
- `evaluate_n_lt_18_compliance.py:_evaluate_case`：统一合规判定与结果结构
- `evaluate_n_lt_18_compliance.py:_main_eval`：批量任务调度、断点续跑、产物输出
- `run_n16_isolated_pipeline.py:_build_cmd`：n=16 参数转发模板

### 4. 测试策略
- **测试框架**: pytest（`tests/`）
- **测试模式**: 新增轻量单元测试，验证分流配置与子进程环境注入
- **参考文件**: `tests/test_solver.py`（sys.path 注入风格）、`tests/test_validation.py`（直接函数验证）
- **覆盖要求**: 覆盖 `n!=16` 默认配置、`n==16` 隔离配置、子进程环境变量注入

### 5. 依赖和集成点
- **外部依赖**: Python subprocess、numpy
- **内部依赖**: `solver.py`、`solver_n16_isolated.py`
- **集成方式**: 在主评测脚本增加“按 n 解析求解配置”的统一分发层
- **配置来源**: CLI 参数 `--ck-*` 与子进程环境变量 `CK_*`

### 6. 技术选型理由
- **为什么用主脚本内分流**: 满足“整体脚本统一入口 + n=16 归属独立分支”目标
- **优势**: 继续使用一套评测流程，同时隔离 n=16 的参数漂移风险
- **劣势和风险**: 参数项增加后，需补测试避免映射错误

### 7. 关键风险点
- **并发问题**: 并行分支必须对每个 case 独立构造配置，不能共享可变状态
- **边界条件**: `--run-one` 模式也要遵守 n=16 分流，否则行为不一致
- **性能瓶颈**: 分流逻辑开销极小，可忽略
- **安全考虑**: 无新增安全逻辑

### 8. 外部检索说明
- `context7`、`github.search_code`、`desktop-commander` 在当前会话不可用，已记录并采用本地代码检索作为替代。
